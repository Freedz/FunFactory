<?
die('Hacking Attempt');
?>