<?php

global $boardurl;

$txt = array();
$txt['home'] = 'Accueil';
$txt['msgs'] = 'Messages';
$txt['myspace'] = 'MySpace';
$txt['twitter'] = 'Tweet';
$txt['facebook'] = 'Facebook';
$txt['whos_on'] = 'Qui est en ligne';
$txt['guest_msg'] = 'Bienvenue, Invit�. Veuillez<a class="white" href="'.$boardurl.'/index.php?action=login">vous identifier</a> ou <a class="white" href="'.$boardurl.'/index.php?action=register">vous inscrire.</a>';
$txt['load_warning'] = 'Le chat n\'est pas disponible � cause d\'une surcharge du serveur.';
?>