<?php

global $boardurl;

$txt = array();
$txt['home'] = 'Home';
$txt['msgs'] = 'Mensagens';
$txt['myspace'] = 'MySpace';
$txt['twitter'] = 'Tweet';
$txt['facebook'] = 'Facebook';
$txt['whos_on'] = 'Quem est&aacute; Online';
$txt['guest_msg'] = 'Bem-vindo, Visitante. Por favor <a class="white" href="'.$boardurl.'/index.php?action=login">Entrar</a> ou <a class="white" href="'.$boardurl.'/index.php?action=register">registar-se.</a>';
$txt['load_warning'] = 'O Chat n&atilde;o esta dispon�vel, devido � alta carregar do servidor.';
?>