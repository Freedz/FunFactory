<?php

global $boardurl;

$txt = array();
$txt['home'] = 'Home';
$txt['msgs'] = 'Messages';
$txt['myspace'] = 'MySpace';
$txt['twitter'] = 'Tweet';
$txt['facebook'] = 'Facebook';
$txt['whos_on'] = 'Who&#39;s Online';
$txt['guest_msg'] = 'Welcome, Guest. Please <a class="white" href="'.$boardurl.'/index.php?action=login">login</a> or <a class="white" href="'.$boardurl.'/index.php?action=register">register.</a>';
$txt['load_warning'] = 'The chat is not availible due to high server load.';
?>