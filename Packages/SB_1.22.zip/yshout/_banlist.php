<?php
$ban_ips_readpost = array (
);
$ban_ips_post = array (
);
$ban_names_readpost = array (
);
$ban_names_post = array (
);
$sbMaintenance = false;
?>