<?php

// Protect album folders
exit;

?>